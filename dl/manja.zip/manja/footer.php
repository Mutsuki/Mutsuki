<div id="footer">
	<p>
		<a href="http://wordpress.org">WordPress</a> & <a href="http://www.koojiafeng.name">Koo</a> powers <?php bloginfo('name'); ?> :: <a href="feed:<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a>
		and <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comments (RSS)</a>
	</p>
</div>
</div>

</div>


		<?php do_action('wp_footer'); ?>

</body>
</html>
