	<div id="sidebar">
		<ul>

				<li>
					<p><a href="http://feeds.feedburner.com/user"><img src="http://feeds.feedburner.com/~fc/user?bg=663399&amp;fg=FFFFFF&amp;anim=1" height="26" width="88" style="border:0" alt="" /></a></p><br>
					<div class="clear"></div>
					<a href="http://technorati.com/faves?sub=addfavbtn&amp;add=http://yourdomain.com"><img src="http://static.technorati.com/pix/fave/tech-fav-1.png" alt="Add to Technorati Favorites" /></a>
				</li>

				<!--
				Author information is disabled per default. Uncomment and fill in your details if you want to use it.
				<li><h2><?php _e('Author'); ?></h2>
				<p>A little something about you, the author. Nothing lengthy, just an overview.</p>
				</li>
				-->


				<li id="wp-calendar">
				<?php get_calendar(); ?>
				</li>

				<h2><?php _e('Recent Entries'); ?></h2>
				<li><ul>
				<?php
				  $recent_posts = wp_get_recent_posts();
				  foreach($recent_posts as $post){
					echo '<li><a href="' . get_permalink($post["ID"]) . '" title="Look '.$post["post_title"].'" >' .   $post["post_title"].'</a> </li> ';
				  } ?>
				</ul></li>

				<h2><?php _e('Recent Comments'); ?></h2>
				<li><ul>
				<?php
				global $wpdb;
				$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
				comment_post_ID, comment_author, comment_date_gmt, comment_approved,
				comment_type,comment_author_url,
				SUBSTRING(comment_content,1,30) AS com_excerpt
				FROM $wpdb->comments
				LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
				$wpdb->posts.ID)
				WHERE comment_approved = '1' AND comment_type = '' AND
				post_password = ''
				ORDER BY comment_date_gmt DESC
				LIMIT 10";
				$comments = $wpdb->get_results($sql);
				$output = $pre_HTML;

				foreach ($comments as $comment) {
				$output .= "\n<li>".strip_tags($comment->comment_author)
				.":" . " <a href=\"" . get_permalink($comment->ID) .
				"#comment-" . $comment->comment_ID . "\" title=\"on " .
				$comment->post_title . "\">" . strip_tags($comment->com_excerpt)
				."</a></li>";
				}

				$output .= $post_HTML;
				echo $output;?>
				<!--<?php wp_get_archives('type=monthly'); ?>-->
				</ul></li>
				

				<!--<h2><?php _e('Archives'); ?></h2>
				<li><ul>
				<?php wp_get_archives('type=monthly'); ?>
				</ul></li>-->

				<h2><?php _e('Categories'); ?></h2>
				<li>
				<ul>
				<?php list_cats(0, '', 'name', 'asc', '', 1, 0, 1, 1, 1, 1, 0,'','','','','') ?>
				</ul>
				</li>

				<?php get_links_list(); ?>

				<li><h2><?php _e('Meta'); ?></h2>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<li><a href="http://validator.w3.org/check/referer" title="<?php _e('This page validates as XHTML 1.0 Transitional'); ?>"><?php _e('Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr>'); ?></a></li>
					<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
					<li><a href="http://wordpress.org/" title="<?php _e('Powered by WordPress, state-of-the-art semantic personal publishing platform.'); ?>">WordPress</a></li>
					<?php wp_meta(); ?>
				</ul>
				</li>

			<?php /*}*/ ?>

		</ul>
	</div>

