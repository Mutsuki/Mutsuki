<?php get_header(); ?>
<div id="article">
<h2>Error 404 - Not Found</h2>
<div class="entry">
What you were looking for isn't here anymore. It might be a temporary error, it might be permanent.
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
抱歉，您要找的内容没有，或者它是个错误，您可以尝试在上面搜索您要找的关键词以便能找到您要的内容。
</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>