<?php
/*
Template Name: Archives
*/
?>
<?php get_header(); ?>
<div id="article">

<div class="section">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<h2>Related Material & Articles & Tags:</h2>
<div class="archives">
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
<h2>Archives by Month:</h2>
<ul><?php wp_get_archives('type=monthly'); ?></ul>

<h2>Archives by Subject:</h2>
<ul><?php wp_list_categories(); ?></ul>

<?php if ( function_exists('wp_tag_cloud') ) : ?>

<h2>Popular Tags:</h2>
<li>
<ul>
<?php wp_tag_cloud('smallest=8&largest=22'); ?>
</ul>
</li>
<?php endif; ?>

<?php endwhile; else: ?>
<?php endif; ?>
</div>
</div>
		

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>