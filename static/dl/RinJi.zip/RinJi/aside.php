<div id="aside">
<div class="singlesidebar">
<p>Posted on the <?php the_time('F jS, Y') ?></p>
<div class="cats">Categories: <?php the_category(', ') ?>
</div>

<div class="tag">
<?php 
     the_tags('<ul><li>','</li><li>','</li></ul>');
?>
</div>

</div>

</div><!-- closes sidebar -->