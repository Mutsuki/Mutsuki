<div id="footer">
<p>Theme by  <a href="http://oopiz.cn">Brando</a>. Valid <a href="http://validator.w3.org/check/referer" class="w3c" title="XHTML 1.1">XHTML</a> and <a href="http://jigsaw.w3.org/css-validator/validator?uri=http://oopiz.cn/wp-content/themes/v7/css/layout.css" title="CSS 2.0">CSS</a>
<br />Copyright ©  2007-2008 <?php bloginfo('name'); ?>  All Rights Reserved.  <a href="<?php bloginfo('rss2_url'); ?>" title="Subscribe to <?php bloginfo('name'); ?> newsfeed"><img src="<?php bloginfo('template_directory'); ?>/images/footer-feedicon.gif" height="12" width="12" alt="feed" class="feedicon" /></a><a href="<?php bloginfo('rss2_url'); ?>" title="Subscribe to <?php bloginfo('name'); ?> newsfeed">RSS</a> <a href="<?php bloginfo('atom_url'); ?>" title="Subscribe to <?php bloginfo('name'); ?> Atom"><img src="<?php bloginfo('template_directory'); ?>/images/footer-feedicon.gif" height="12" width="12" alt="feed" class="feedicon" /></a><a href="<?php bloginfo('atom_url'); ?>" title="Subscribe to <?php bloginfo('name'); ?> Atom">Atom</a></p>
<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>