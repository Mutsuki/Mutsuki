<?php get_header(); ?>
<div id="article">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="section" id="post-<?php the_ID(); ?>">
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="entry">
<?php the_content(__('')); ?>
<!--
<?php trackback_rdf(); ?>
-->
</div>

<ul class="meta">
<li class="more">{ <a href="<?php the_permalink() ?>">more</a> }</li>
<li class="date"><?php the_date() ?></li>
<li class="commentinfo"><?php comments_popup_link(__(' Speak Up!'), __('1 Commenatrios '), __('% Commenatrios '),__('comments-link'),__('Comments are off for this post')); ?></li>
</ul>
</div>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>