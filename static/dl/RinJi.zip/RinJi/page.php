<?php
/*
Template Name: Archives
*/
?>
<?php get_header(); ?>
<div id="article">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="section">
<h2><?php the_title(); ?></h2>
<div class="archives">
<?php the_content(__('')); ?>
</div>
</div>
		
<?php endwhile; else: ?>
<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>