<div id="aside">
<div class="nav">

<div class="pages">
<h2>Pages</h2>
<ul><?php wp_list_pages('title_li=&depth=1'); ?></ul>
</div>	

<div class="categories">
<h2>Categories</h2>
<ul><?php wp_list_cats('sort_column=name&list=1&optioncount=0&feed=RSS'); ?></ul>
</div>			

<div class="archives">
<h2>Archives</h2>
<ul><?php wp_get_archives('type=monthly'); ?></ul>
</div>	

<div class="blogroll">
<h2>Blogroll</h2>
<ul>
<?php wp_list_bookmarks('categorize=0&title_li'); ?>
</ul>
</div>


<div class="meta">
<h2>License</h2>
<div class="widget"><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/cn/">
<img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-nd/2.5/cn/80x15.png" />
</a>
<br />本作品采用<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/2.5/cn/">知识共享署名-非商业性使用-禁止演绎 2.5 中国大陆许可协议</a>进行许可。
</div>
</div>
</div>
</div>