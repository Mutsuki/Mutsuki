<?php get_header(); ?>
<div id="article">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

<div class="section" id="post-<?php the_ID(); ?>">
<h2><?php the_title(); ?></h2>
<div class="entry">
<?php the_content('<p class="serif">Read the rest of this entry &raquo;</p>'); ?>
</div>

		<div class="navigation">
			<div class="alignleft"><?php previous_post_link('&laquo; %link') ?></div>
			<div class="alignright"><?php next_post_link('%link &raquo;') ?></div>
		</div>

<?php comments_template(); // Get wp-comments.php template ?>

</div>
</div>
<?php include(TEMPLATEPATH . '/aside.php'); ?>

<?php endwhile; else: ?>
<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
<?php endif; ?>

<?php get_footer(); ?>